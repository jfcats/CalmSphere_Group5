import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
} from "./chunk-WY372UHM.js";
import "./chunk-CBSJCWJ5.js";
import "./chunk-WGRCPX6P.js";
import "./chunk-YHCV7DAQ.js";
export {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
};
