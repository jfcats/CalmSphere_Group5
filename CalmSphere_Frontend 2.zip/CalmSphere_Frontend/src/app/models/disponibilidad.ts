export class Disponibilidad {
  disponibilidadId: number = 0;
  diaSemana: number = 0;      // 1–7 (lunes–domingo)
  horaInicio: string = '';    // 'HH:mm'
  horaFin: string = '';       // 'HH:mm'
}
