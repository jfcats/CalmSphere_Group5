export class MetodoPago {
  idMetodoPago: number = 0;
  nombre: string = '';
  tipo: string = '';
  estado: boolean = true;
}
