import { Usuario } from './usuario';

export class Rol {
  idRol: number = 0;
  tipoRol: string = '';
  idUsuario: Usuario = new Usuario();
}
