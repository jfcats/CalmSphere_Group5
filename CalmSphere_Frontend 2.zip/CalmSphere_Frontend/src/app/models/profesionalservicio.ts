export class ProfesionalServicio {
  idProfesionalServicio: number = 0;
  nombre: string = '';
  duracionMin: number = 0;
  precioBase: number = 0;
  idDisponibilidad: number = 0;
  idUsuario: number = 0;
}
